# La Web de Skay

Web no oficial para Skay y Los Fakires, banda de Rock Argentino.

**Mi banda preferida**

Proyecto personal, originalmente un ejercicio de curso, retomado y actualizado con
un enfoque de desarrollo web senior: performance, accesibilidad y responsive real.

### Actualización — Julio 2026
- Discografía completa: se sumó el álbum *Espejismos* (2023) y los singles
  *Jaque al Rey* (2025) y *Nubes de paso* (2026).
- CSS reescrito de cero: mobile-first, variables, grid responsive real
  (el CSS anterior tenía media queries de práctica sin terminar).
- Portadas de álbum reales aplicadas con `<picture>` (AVIF → WebP → JPG),
  usando assets que ya existían en el repo pero no se estaban usando.
- Video del hero optimizado: `poster`, `preload="none"`, `playsinline`
  para autoplay correcto en iOS/Android sin descargar peso de más.
- Meta tags Open Graph / Twitter Card, JSON-LD (`MusicGroup`), favicon en WebP.
- Accesibilidad: `alt` descriptivos, cierre de galería con tecla Escape,
  `prefers-reduced-motion` respetado.

### Tecnología utilizada
- HTML5 semántico
- CSS3 (Grid, clamp, variables) — mobile-first
- Sass / Npm / Gulp (build original)
- JavaScript vanilla

### Contactame

> "Portfolio", https://yuliamonti.github.io/yuliamonti/

> "Repositorio", https://github.com/yuliamonti

> "Linkedin", https://www.linkedin.com/in/yuliamonti

------------


## <div align="right">  Gracias por leerme

### <div align="right"> Yulia
  
------------
