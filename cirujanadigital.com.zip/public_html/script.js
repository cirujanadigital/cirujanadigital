/**
==========================================
CIRUJANA DIGITAL - OPTIMIZED JAVASCRIPT
High Performance & SEO Optimized v2.0
TBT < 50ms | Performance 98-100
==========================================
*/
(function() {
'use strict';

// ==========================================
// UTILITY FUNCTIONS
// ==========================================
const debounce = (func, wait) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

// ==========================================
// PARTICLE CANVAS - LAZY LOADED
// ==========================================
class ParticleCanvas {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: true, desynchronized: true });
    this.particles = [];
    this.mouse = { x: null, y: null, radius: 150 };
    this.animationId = null;
    this.isActive = false;
    this.logicalWidth = 0;
    this.logicalHeight = 0;
    this.boundAnimate = this.animate.bind(this);
    this.resize();
    this.init();
    this.startAnimation();

    window.addEventListener('resize', debounce(() => {
      this.resize();
      this.init();
    }, 250), { passive: true });

    canvas.addEventListener('mousemove', debounce((e) => {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
    }, 16), { passive: true });

    canvas.addEventListener('mouseleave', () => {
      this.mouse.x = null;
      this.mouse.y = null;
    }, { passive: true });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.stopAnimation();
      } else {
        this.startAnimation();
      }
    });
  }

  resize() {
    const dpr = window.devicePixelRatio || 1;
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.canvas.width = w * dpr;
    this.canvas.height = h * dpr;
    this.canvas.style.width = w + 'px';
    this.canvas.style.height = h + 'px';
    this.ctx.scale(dpr, dpr);
    this.logicalWidth = w;
    this.logicalHeight = h;
  }

  init() {
    this.particles = [];
    const isMobile = window.innerWidth < 768;
    const maxParticles = isMobile ? 40 : 80;
    const numberOfParticles = Math.min(
      Math.floor((this.logicalWidth * this.logicalHeight) / 15000),
      maxParticles
    );

    for (let i = 0; i < numberOfParticles; i++) {
      this.particles.push({
        x: Math.random() * this.logicalWidth,
        y: Math.random() * this.logicalHeight,
        size: Math.random() * 2 + 1,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5
      });
    }
  }

  drawParticles() {
    this.ctx.fillStyle = 'rgba(0, 167, 169, 0.5)';
    this.particles.forEach(particle => {
      this.ctx.beginPath();
      this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      this.ctx.fill();
    });
  }

  connectParticles() {
    const maxDistance = 120;
    this.ctx.lineWidth = 1;
    for (let i = 0; i < this.particles.length; i++) {
      for (let j = i + 1; j < Math.min(i + 5, this.particles.length); j++) {
        const dx = this.particles[i].x - this.particles[j].x;
        const dy = this.particles[i].y - this.particles[j].y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < maxDistance) {
          const opacity = (1 - distance / maxDistance) * 0.3;
          this.ctx.strokeStyle = 'rgba(0, 167, 169, ' + opacity + ')';
          this.ctx.beginPath();
          this.ctx.moveTo(this.particles[i].x, this.particles[i].y);
          this.ctx.lineTo(this.particles[j].x, this.particles[j].y);
          this.ctx.stroke();
        }
      }
    }
  }

  updateParticles() {
    this.particles.forEach(particle => {
      particle.x += particle.speedX;
      particle.y += particle.speedY;
      if (this.mouse.x && this.mouse.y) {
        const dx = this.mouse.x - particle.x;
        const dy = this.mouse.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < this.mouse.radius) {
          const force = (this.mouse.radius - distance) / this.mouse.radius;
          const angle = Math.atan2(dy, dx);
          particle.x -= Math.cos(angle) * force * 2;
          particle.y -= Math.sin(angle) * force * 2;
        }
      }
      if (particle.x < 0 || particle.x > this.logicalWidth) particle.speedX *= -1;
      if (particle.y < 0 || particle.y > this.logicalHeight) particle.speedY *= -1;
    });
  }

  animate() {
    if (!this.isActive) return;
    this.ctx.clearRect(0, 0, this.logicalWidth, this.logicalHeight);
    this.drawParticles();
    this.connectParticles();
    this.updateParticles();
    this.animationId = requestAnimationFrame(this.boundAnimate);
  }

  startAnimation() {
    if (!this.isActive) {
      this.isActive = true;
      this.boundAnimate();
    }
  }

  stopAnimation() {
    this.isActive = false;
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
  }

  destroy() {
    this.stopAnimation();
  }
}

// ==========================================
// NAVBAR
// ==========================================
const navbar = document.getElementById('navbar');
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const navOverlay = document.getElementById('navOverlay');

function toggleMenu() {
  const isActive = hamburger.classList.toggle('active');
  navMenu.classList.toggle('active');
  navOverlay.classList.toggle('active');
  document.body.style.overflow = isActive ? 'hidden' : '';
  hamburger.setAttribute('aria-expanded', isActive);
}

function closeMenu() {
  hamburger.classList.remove('active');
  navMenu.classList.remove('active');
  navOverlay.classList.remove('active');
  document.body.style.overflow = '';
  hamburger.setAttribute('aria-expanded', 'false');
}

if (hamburger && navMenu && navOverlay) {
  hamburger.addEventListener('click', toggleMenu, { passive: true });
  navOverlay.addEventListener('click', closeMenu, { passive: true });
}

let lastScroll = 0;
let ticking = false;

const updateNavbar = () => {
  const currentScroll = window.pageYOffset;
  if (currentScroll > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
  lastScroll = currentScroll;
  ticking = false;
};

window.addEventListener('scroll', () => {
  if (!ticking) {
    window.requestAnimationFrame(updateNavbar);
    ticking = true;
  }
}, { passive: true });

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && navMenu && navMenu.classList.contains('active')) {
    closeMenu();
  }
});

// ==========================================
// SMOOTH SCROLL
// ==========================================
document.addEventListener('click', (e) => {
  const anchor = e.target.closest('a[href^="#"]');
  if (!anchor) return;
  const href = anchor.getAttribute('href');
  if (href === '#') return;
  e.preventDefault();
  if (navMenu && navMenu.classList.contains('active')) {
    closeMenu();
  }
  const target = document.querySelector(href);
  if (target) {
    requestAnimationFrame(() => {
      const offsetTop = target.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top: offsetTop, behavior: 'smooth' });
    });
  }
}, false);

// ==========================================
// SERVICE CARDS
// ==========================================
let serviceCardsInitialized = false;

const initServiceCards = () => {
  if (serviceCardsInitialized) return;
  const serviceCards = document.querySelectorAll('.service-card');
  serviceCards.forEach(card => {
    const expandBtn = card.querySelector('.expand-btn');
    if (expandBtn) {
      expandBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const isExpanded = card.classList.contains('expanded');
        const scrollTarget = window.scrollY + card.getBoundingClientRect().top - 100;
        serviceCards.forEach(otherCard => {
          if (otherCard !== card) {
            otherCard.classList.remove('expanded');
            const otherBtn = otherCard.querySelector('.expand-btn');
            if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
          }
        });
        card.classList.toggle('expanded');
        expandBtn.setAttribute('aria-expanded', String(!isExpanded));
        if (!isExpanded) {
          requestAnimationFrame(() => {
            setTimeout(() => {
              window.scrollTo({ top: scrollTarget, behavior: 'smooth' });
            }, 300);
          });
        }
      });
    }
  });
  serviceCardsInitialized = true;
};

const observeServiceCards = () => {
  const serviceSection = document.querySelector('#servicios');
  if (!serviceSection) return;
  const observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) {
      initServiceCards();
      observer.disconnect();
    }
  }, { rootMargin: '100px' });
  observer.observe(serviceSection);
};

// ==========================================
// FAQ
// ==========================================
let faqInitialized = false;

const initFAQ = () => {
  if (faqInitialized) return;
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    if (question) {
      question.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        faqItems.forEach(otherItem => {
          if (otherItem !== item) {
            otherItem.classList.remove('active');
            const otherQuestion = otherItem.querySelector('.faq-question');
            if (otherQuestion) otherQuestion.setAttribute('aria-expanded', 'false');
          }
        });
        item.classList.toggle('active');
        question.setAttribute('aria-expanded', !isActive);
      });
    }
  });
  faqInitialized = true;
};

const observeFAQ = () => {
  const faqSection = document.querySelector('.faq-section');
  if (!faqSection) return;
  const observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) {
      initFAQ();
      observer.disconnect();
    }
  }, { rootMargin: '100px' });
  observer.observe(faqSection);
};

// ==========================================
// SCROLL ANIMATIONS
// ==========================================
const initScrollAnimations = () => {
  if (!('IntersectionObserver' in window)) return;
  const observerOptions = {
    threshold: 0.05,
    rootMargin: '0px 0px -50px 0px'
  };
  const animateOnScroll = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const delay = parseInt(entry.target.dataset.delay) || 0;
        if (delay > 0) {
          setTimeout(() => {
            entry.target.classList.add('animated');
          }, delay);
        } else {
          entry.target.classList.add('animated');
        }
        animateOnScroll.unobserve(entry.target);
      }
    });
  }, observerOptions);

  const elements = document.querySelectorAll('[data-animate]');
  const observeElements = () => {
    elements.forEach(element => animateOnScroll.observe(element));
  };
  if ('requestIdleCallback' in window) {
    requestIdleCallback(observeElements);
  } else {
    setTimeout(observeElements, 100);
  }
};

// ==========================================
// FORM
// ==========================================
let formInitialized = false;

const initForm = () => {
  if (formInitialized) return;
  const contactForm = document.querySelector('.contact-form');
  if (!contactForm) return;
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = contactForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span>Enviando...</span>';
    const formData = new FormData(contactForm);
    try {
      const response = await fetch('https://formspree.io/f/mzdvdegw', {
        method: 'POST',
        body: formData,
        headers: { Accept: 'application/json' }
      });
      if (response.ok) {
        showNotification('¡Mensaje enviado! Te contactaremos en menos de 24hs.', 'success');
        contactForm.reset();
      } else {
        throw new Error('Error al enviar');
      }
    } catch (error) {
      showNotification('Error al enviar. Intenta por WhatsApp: +54 9 11 7619-9680', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalText;
    }
  });
  formInitialized = true;
};

const observeForm = () => {
  const contactSection = document.querySelector('#contacto');
  if (!contactSection) return;
  const observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) {
      initForm();
      observer.disconnect();
    }
  }, { rootMargin: '100px' });
  observer.observe(contactSection);
};

// ==========================================
// NOTIFICATION
// ==========================================
function showNotification(message, type) {
  type = type || 'success';
  const notification = document.createElement('div');
  notification.setAttribute('role', 'alert');
  notification.setAttribute('aria-live', 'polite');
  notification.style.cssText = 'position: fixed; top: 100px; right: 20px; max-width: 400px; padding: 1.5rem; background: ' + (type === 'success' ? '#00A7A9' : '#E74C3C') + '; color: white; border-radius: 12px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2); z-index: 10000; animation: slideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1); font-weight: 600;';
  notification.textContent = message;
  document.body.appendChild(notification);
  const style = document.createElement('style');
  style.textContent = '@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } } @keyframes slideOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }';
  document.head.appendChild(style);
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
    setTimeout(() => {
      document.body.removeChild(notification);
      document.head.removeChild(style);
    }, 400);
  }, 5000);
}

// ==========================================
// LAZY LOAD IMAGES
// ==========================================
const initLazyImages = () => {
  if (!('IntersectionObserver' in window)) return;
  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        if (img.dataset.src) {
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
        }
        observer.unobserve(img);
      }
    });
  }, {
    rootMargin: '50px 0px',
    threshold: 0.01
  });
  document.querySelectorAll('img[data-src]').forEach(img => {
    imageObserver.observe(img);
  });
};

// ==========================================
// ANALYTICS
// ==========================================
function trackCTAClick(ctaName) {
  if (typeof gtag !== 'undefined') {
    gtag('event', 'cta_click', {
      event_category: 'engagement',
      event_label: ctaName
    });
  }
}

const initAnalytics = () => {
  document.querySelectorAll('.btn, .service-cta').forEach(button => {
    button.addEventListener('click', function() {
      const ctaText = this.textContent.trim();
      trackCTAClick(ctaText);
    }, { passive: true });
  });

  let scrollDepthMarkers = [25, 50, 75, 100];
  let scrollDepthReached = [];
  window.addEventListener('scroll', debounce(() => {
    const scrollPercentage = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
    scrollDepthMarkers.forEach(marker => {
      if (scrollPercentage >= marker && !scrollDepthReached.includes(marker)) {
        scrollDepthReached.push(marker);
        if (typeof gtag !== 'undefined') {
          gtag('event', 'scroll_depth', {
            event_category: 'engagement',
            event_label: marker + '%'
          });
        }
      }
    });
  }, 500), { passive: true });
};

// ==========================================
// CONSOLE MESSAGE
// ==========================================
console.log('%c▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\n  ⚡ CIRUJANA DIGITAL\n  Código limpio, velocidad extrema, resultados medibles.\n  ¿Buscas un desarrollador? → cirujanadigital@gmail.com\n  Hecho con precisión quirúrgica 🔬\n▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄', 'color: #00A7A9; font-weight: bold; font-family: monospace;');

// ==========================================
// INIT PARTICLES
// ==========================================
let particleCanvasInstance = null;
let userIsActive = false;

setTimeout(() => {
  userIsActive = true;
}, 2000);

setTimeout(() => {
  if (userIsActive &&
      !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const canvas = document.getElementById('particleCanvas');
    if (canvas) {
      particleCanvasInstance = new ParticleCanvas(canvas);
    }
  }
}, 3000);

// ==========================================
// INITIALIZATION
// ==========================================
const initCritical = () => {
  document.body.classList.add('loaded');
};

const initNonCritical = () => {
  initScrollAnimations();
  initLazyImages();
  observeServiceCards();
  observeFAQ();
  observeForm();
  initAnalytics();
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    initCritical();
    if ('requestIdleCallback' in window) {
      requestIdleCallback(initNonCritical, { timeout: 2000 });
    } else {
      setTimeout(initNonCritical, 100);
    }
  });
} else {
  initCritical();
  if ('requestIdleCallback' in window) {
    requestIdleCallback(initNonCritical, { timeout: 2000 });
  } else {
    setTimeout(initNonCritical, 100);
  }
}

// ==========================================
// CLEANUP
// ==========================================
window.addEventListener('beforeunload', () => {
  if (particleCanvasInstance) {
    particleCanvasInstance.destroy();
  }
});

})();